import './Header.css'

function Header() {
  return (
    <div className="Header-wrapper">
      <h1>Project Management Board</h1>
    </div>
  )
}

export default Header;