import Products from './products'

export default function Home() {
  return <Products />
}
