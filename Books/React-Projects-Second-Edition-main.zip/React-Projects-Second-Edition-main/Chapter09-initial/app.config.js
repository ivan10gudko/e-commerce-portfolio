export default {
    extra: {
      apiUrl: 'http://LOCAL_IP_ADDRESS:3000',
    },
  };