### Chapter 10 assets

This directory contains assets that you need for chapter 10:

- `beach.jpeg`
- `mountain.jpeg`
- `Ingenuity_v3.glb` (Copyright [NASA](https://mars.nasa.gov/resources/25043/mars-ingenuity-helicopter-3d-model/))
