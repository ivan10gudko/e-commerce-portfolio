import React, { createRef } from 'react';

export const navigationRef = createRef();
